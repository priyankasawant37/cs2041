#!/usr/bin/perl
print("=========SET1_0=========\n");
$a = 2;
$b = 3;
print("\\\$a$a$b\tcool\n");
#print: \$a23 (newline)
