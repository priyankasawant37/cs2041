#!/usr/bin/perl
# if, elsif, else
print("=========SET2_1=========\n");
$j = 10;
if ($j < 3) {
    print "$j less than 3\n";
} elsif ($j < 5) {
    print "$j less than 5\n";
} else {
    print "$j greater than 5\n";
}

if (            $j >= 10            )


            {
                            if ($j >= 15) {
print "$j >= 15\n";
            } elsif($j >= 12){ print "12 <= $j < 15\n";
}else{print "10 <= $j < 12\n";}
}
