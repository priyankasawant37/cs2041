#!/usr/bin/perl
print("=========SET2_4=========\n");
# grouping with set 2 stuff

print(2 + 3 <=> 5 - 4,"\n");      # 1

print(2 + 3 - (5 - 4 <=> 7),"\n");     # 5 -(-1) = 6
