#!/usr/bin/perl
print("=========SET1_1=========\n");
print(2+3   - 5 * 7 ** 3 / 11*+-+- -15 % 13);
# ans 3
