#!/usr/bin/perl -w
print("=========SET3_9=========\n");
@a = split(" ", "abc def");
print(join(",", @a),"\n");

print(join("-","1", "2","3" , "4" , "5"),"\n");
