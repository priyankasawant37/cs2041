#!/usr/bin/perl
print("=========SET2_2=========\n");
# for
$j = 10;
for ($i = 0; $i < 5, $j > 0; $i = $i + 1, $j = $j -1) {
    print "$i and $j\n";
}
