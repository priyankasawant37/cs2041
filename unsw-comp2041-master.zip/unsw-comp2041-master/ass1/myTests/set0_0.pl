#!/usr/bin/perl -w
print("=========SET0_0=========\n");
# integer
print   (5);        # 5
print("\n");
print( - 15 );      # -15
print("\n");
# float
print(.3);          # 0.3
print("\n");
print(0.3);         # 0.3
print("\n");
print(-.3e+2);
print("\n");
# binary
print(0b11_01);     # 13
print("\n");
# octal
print(- +   -	+  -		+010);         # 8
print("\n");
# hex
print(0xFF);        # 255
print("\n");
# weird case
#print(5+.3.3);
#print("\n");
