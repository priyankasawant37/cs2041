#!/usr/bin/perl
print("=========SET2_6=========\n");
print(0.3E-2,"\n");
print(0xFE,"\n");
