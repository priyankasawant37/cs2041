#!/usr/bin/perl
print("=========SET1_2=========\n");
$a=4;$b=5;
print("$a $b\n");
