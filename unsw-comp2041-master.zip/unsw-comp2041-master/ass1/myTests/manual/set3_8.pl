#!/usr/bin/perl -w
@a = @ARGV;
foreach $i (0..$#a) {
    print "$    a[   $   i   ]\n";
}
