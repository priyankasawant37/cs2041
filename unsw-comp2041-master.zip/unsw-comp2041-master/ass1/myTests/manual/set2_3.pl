#!/usr/bin/perl
print("=========SET2_3=========\n");
# foreach
print("**** (part 2)\n");
$k = 500;
foreach $i ($k) {
    print "$i\n";
}
# can't actually run this in python...
