#!/usr/bin/perl
print("=========SET3_5=========\n");
print(1,"\n");

#exit 1;

#exit ( "lolok" ) ;     # works in perl but is it meaningful?
exit(4 * 6 / 2 + 3 ** 5);

print(2,"\n");
