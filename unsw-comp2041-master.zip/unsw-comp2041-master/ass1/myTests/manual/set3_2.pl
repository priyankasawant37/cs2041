#!/usr/bin/perl
print("=========SET3_2=========\n");
$line=<stdin>;
print($line);
