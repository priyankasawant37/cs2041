#!/usr/bin/perl
print("=========SET3_3=========\n");
$a = 3;
print($a,"\n");
--$a;
print($a,"\n");
++$a;
print($a,"\n");
$a--;
print($a,"\n");
$a++;
print($a,"\n");
# 3 2 3 2 3
