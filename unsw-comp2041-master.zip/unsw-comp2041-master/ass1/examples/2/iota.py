#!/usr/local/bin/python3.5 -u

x = 1
while x <= 10:
    print(x)
    x = x + 1
