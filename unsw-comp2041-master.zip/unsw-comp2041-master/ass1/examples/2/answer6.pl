#!/usr/bin/perl -w
$answer = 0;
while ($answer < 36) {
    $answer = $answer + 7;
}
print "$answer\n";
