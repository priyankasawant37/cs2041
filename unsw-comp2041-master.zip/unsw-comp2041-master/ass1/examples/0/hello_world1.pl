#!/usr/bin/perl -w

print ("hello world\n");

print "hello world";
print ("hello world");

#print (("hello world"));
