#!/usr/local/bin/python3.5 -u

print("hello world")
