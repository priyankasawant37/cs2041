#!/usr/local/bin/python3.5 -u
import sys

for i in range(len(sys.argv) - 1):
    print(sys.argv[i + 1])
