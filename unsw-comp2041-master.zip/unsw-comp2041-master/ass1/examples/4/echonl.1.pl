#!/usr/bin/perl -w

foreach $i (0..$#ARGV) {
    print "$ARGV[$i]\n";
}
