#!/usr/local/bin/python3.5 -u
import sys

for arg in sys.argv[1:]:
    print(arg)
