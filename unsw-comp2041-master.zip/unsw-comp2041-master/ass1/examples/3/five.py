#!/usr/local/bin/python3.5 -u

for i in range(0, 5):
    print(i)

