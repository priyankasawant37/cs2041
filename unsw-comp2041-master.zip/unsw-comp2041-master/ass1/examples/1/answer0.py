#!/usr/local/bin/python3.5 -u

answer = 42
print(answer)
