#!/usr/local/bin/python3.5 -u

answer = 6 * 7
print(answer)
