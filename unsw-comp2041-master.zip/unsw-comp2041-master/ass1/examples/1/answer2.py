#!/usr/local/bin/python3.5 -u

answer = 1 + 7 * 7 - 8
print(answer)
