#!/usr/bin/perl -w

$answer = 6 * 7;
print "$answer\n";
