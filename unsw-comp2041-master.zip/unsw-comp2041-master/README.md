# unsw-comp2041
Lab and assignment files for the COMP2041 course: Software Construction and Tools.
The course is an introduction to scripting in Bash, Perl, and Python, as well as an introduction to cgi scripting (gaining exposure to at least html and css).
