#!/usr/bin/env python3

a = ['abcobw\n','bfpaigw\n','capgbaegag\n']
print(a)
print('-----------')
b = ''.join(a)
b = b.replace('\n','')
print(b)
