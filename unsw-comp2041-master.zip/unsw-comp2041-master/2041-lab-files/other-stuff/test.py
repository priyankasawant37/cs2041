#!/usr/bin/env python3.5

def main():
	a = [1,2,3,4,5,6,7]
	#print(a[1,4])
	print(a[1:4])


print("ASF")

if __name__ == '__main__':
	main()

print("END")
